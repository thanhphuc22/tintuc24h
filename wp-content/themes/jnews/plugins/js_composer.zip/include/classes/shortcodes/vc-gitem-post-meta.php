<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Class WPBakeryShortCode_Vc_Gitem_Post_Meta
 */
class WPBakeryShortCode_Vc_Gitem_Post_Meta extends WPBakeryShortCode {
}
